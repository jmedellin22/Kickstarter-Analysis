#Module 1 Challenge Kickstarter

Campaign Outcomes based on Launch Dates and Funding Goals

We are creating this analysis to further help Louise understand how different compaigns fared in relation to their launch dates and funding goals.

We were able to generate analysis using data from other campaigns launch dates and funding goals to discover what percentages of other similar campaigns that were either successful, failed or canceled respectively.

#Outcomes Based on Launch Date
The analysis here shows, I believe, that a trend of more successful outcomes with launch dates more set between the months of April through Mid July where it starts to tail off as you get closer to the end of the year.  
It also shows Failures to be pretty consistend throughout the year but with a little less failure towards the end of the year, but I believe that may be attributed more so to less productions overall. 

#Analysis of Outcomes Based on Goals
The analysis here shows, I believe, that a trend of campaigns with lower goal amounts tend to be more successful, with less than $1000 and also $1000 to $4999 ranges, we saw the highest percentage of succesful outcomes with almost 75% respective for both.
Every range beyond that dips to about 50% and continues to trend downward until you reach the $35000 range.

#Challenges and Difficulties Encountered
There were a few challenges, the first being I wasn't sure if we were supposed to use the Kickstarter spreadsheet that we had already been working on through the module and continue off of that one, or if we
were supposed to redownload the file again and start from scratch. However, I was able to get the project done correctly I believe, but if I need to make the corrections to a new spreadsheet and not the one previously used for the 1st Module,
I will do so, just let me know please. Beyond that, the only other challenge I ran into was the Data points towards the end of my line chart werent matching up with the data points in the visual given on the module.
Im not sure if that has to do with me using the already updated spreadsheet, but for some reason I couldnt get it to match the ending data points shown.

#Results
 1. Campaigns tend to be more successful with launch dates earlier in the year around summertime
2. Campaigns tend to be less successful with launch dates towards the end of the year around wintertime. 

#Results
1. Campaigns tend to be more successful with lower goal amounts, and tend to be ever more successful for the amount ranges of less than $1000, and between $1000 and $4999.

#Results
1. We are unable to conclude any trends with canceled campaigns given limitations on the data, or i'm using the incorrect spreadsheet (LOL)

#Results
1.I believe we could create some charts or graphs that might display perhaps the trend between campaigns that are successful or failure and the amount of backers each succesful or failed campaign had to
display any data that might support the amount of backers needed to be successful.
